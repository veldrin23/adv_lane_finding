import numpy as np
import cv2
import matplotlib.pyplot as plt


def color_pipe(img, thresh=(170, 255)):
    img = np.copy(img)
    # Convert to HSV color space and separate the V channel
    hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HLS).astype(np.float)
    hsv_h = hsv[:, :, 0]
    hsv_s = hsv[:, :, 1]
    hsv_v = hsv[:, :, 2]
    hls = cv2.cvtColor(img, cv2.COLOR_RGB2HSV).astype(np.float)
    hls_h = hls[:, :, 0]
    hls_l = hls[:, :, 1]
    hls_s = hls[:, :, 2]

    combined = np.zeros_like(hls_l)
    combined[(hsv_s >= thresh[0]) & (hsv_s < thresh[1]) |
             (hsv_v >= thresh[0]) & (hsv_v < thresh[1]) |
             (hls_l >= thresh[0]) & (hls_l < thresh[1]) |
             (hls_s >= thresh[0]) & (hls_s < thresh[1])] = 1

    return combined





